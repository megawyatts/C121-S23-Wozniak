package packagesDemo;

public class Podcast {
    //String podName, genre, producer, author;
    public String podName;
    public String genre;
    private String producer;
    private String author;
    private int pubYear;

    public Podcast(String podName, String genre, String producer, String author, int pubYear){
        this.podName=podName;
        this.genre=genre;
        this.producer=producer;
        this.author=author;
        this.pubYear=pubYear;
    }
    public void calculateYears(){
        int yearsRunning;
        this.pubYear=getYear();
        yearsRunning=2023-pubYear;
        System.out.printf("%s has been running for %d years!\n",podName, yearsRunning);
    }
    public void printPodcast(){
        this.producer=getProducer();
        this.author=getAuthor();
        System.out.printf("The podcast: %s is produced by %s and written by %s\n",podName,producer,author);
    }
    public String getProducer(){
        return producer;
    }
    public String getAuthor(){
        return author;
    }
    public int getYear(){
        return pubYear;
    }
}
