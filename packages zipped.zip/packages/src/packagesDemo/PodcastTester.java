package packagesDemo;

import java.util.Scanner;
public class PodcastTester {
    public static void main(String[]args){
        String podName,genre,producer,author;
        int pubYear;
        Scanner keyboard=new Scanner(System.in);

        System.out.print("What is the name of the podcast?\n");
        podName=keyboard.nextLine();
        System.out.printf("What is the genre of the Podcast: %s?\n",podName);
        genre=keyboard.nextLine();
        System.out.printf("What is %s's producer?\n",podName);
        producer=keyboard.nextLine();
        System.out.printf("Who is the author of %s?\n",podName);
        author=keyboard.nextLine();
        System.out.printf("What year was %s published?\n",podName);
        pubYear=Integer.parseInt(keyboard.nextLine());

        Podcast podcastNew= new Podcast(podName,genre,producer,author,pubYear);
        podcastNew.printPodcast();
        podcastNew.calculateYears();



    }
}
