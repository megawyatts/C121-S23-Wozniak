public class Main {
    public static void main(String[] args){
        Sorting sorter= new Sorting();
        int[] userArray=sorter.getArray();
        for(int i=0;i<=userArray.length-1;i++){
            System.out.printf("%d, ",userArray[i]);
        }
        System.out.println("\n");
        userArray=sorter.sortArray(userArray);
        for(int j=0;j<=userArray.length-1;j++){
            System.out.printf("%d, ",userArray[j]);
        }
    }
}
