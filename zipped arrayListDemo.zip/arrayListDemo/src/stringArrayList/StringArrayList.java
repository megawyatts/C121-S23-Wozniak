package stringArrayList;

import java.util.ArrayList;
public class StringArrayList {
    public ArrayList<String> names= new ArrayList<>();

    public void addName(String newName){
        names.add(newName);
    }
    public void removeName(String targetName){
        names.remove(targetName);
    }
    public int sizeNames(){
        return names.size();
    }
    public String retrieveIndexNames(int index){
        return names.get(index);
    }
    public void forEachNames(){
        for(String name : names){
            System.out.printf("%s\n",name);
        }
    }
    public void forLoopNames(){
        for(int i=0;i<names.size();i++){
            System.out.printf("%s\n",names.get(i));
        }
    }

}
