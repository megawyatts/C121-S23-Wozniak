package stringArrayList;
import java.util.ArrayList;
public class StringArrayListTest {
    public static void main(String[]args){
        StringArrayList names= new StringArrayList();

        names.addName("Juno");
        names.addName("Peter");
        names.addName("Buddy");
        names.addName("Vespa");
        names.addName("Rita");
        names.addName("Jett");
        names.addName("Mercury");

        System.out.printf("Names has %d names in it\n",names.sizeNames());

        names.removeName("Mercury");
        System.out.printf("Names now has %d names in it.\n",names.sizeNames());

        System.out.printf("The fourth name in the list is %s\n",names.retrieveIndexNames(3));

        System.out.println("For each loop:");
        names.forEachNames();
        System.out.println("Normal For Loop:");
        names.forLoopNames();
    }
}
