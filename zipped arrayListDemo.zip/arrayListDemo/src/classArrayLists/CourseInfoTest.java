package classArrayLists;

import java.util.Scanner;
public class CourseInfoTest {
    public static void main(String[] args){
        CourseInfo courses= new CourseInfo();
        String input;
        String courseName;
        int score;
        double gpa;
        char letter;
        Scanner keyboard=new Scanner(System.in);

        while (true){
            System.out.println("Enter either the name of the course, or\"q\" to quit and see the table");
            input=keyboard.nextLine();
            if ((input.equals("q"))||(input.equals("Q"))){
                courses.printCourseInfo();
                break;
            }else{
                courseName=input;
                System.out.printf("What is your score in %s\n",input);
                score=Integer.parseInt(keyboard.nextLine());
                System.out.printf("What is your GPA in %s\n",input);
                gpa=Double.parseDouble(keyboard.nextLine());
                System.out.printf("What is your letter grade in %s\n",input);
                input=keyboard.nextLine();
                letter=input.charAt(0);

                courses.addCourseTitle(courseName,gpa,score,letter);

            }

        }
    }
}
