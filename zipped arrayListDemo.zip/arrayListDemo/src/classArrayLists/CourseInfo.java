package classArrayLists;
import java.util.ArrayList;
public class CourseInfo {
    ArrayList<String> courseInfo= new ArrayList<>();

    public void addCourseTitle(String courseName,double gpa,int score, char letterGrade){
        String text=String.format("%s\t%f0.2\t%d\t%c",courseName,gpa,score,letterGrade);
        courseInfo.add(text);
    }
    public void printCourseInfo(){
        System.out.println("Course Title\tGPA\tScore\tLetterGrade");
        for (String course: courseInfo){
            System.out.println(course);
        }
    }
}
