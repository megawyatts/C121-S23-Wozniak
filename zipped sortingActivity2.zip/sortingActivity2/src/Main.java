public class Main {
    public static void main(String[] args){
        Sorting sorter=new Sorting();
        int[] array;
        array=sorter.getArray();
        System.out.println("\nUnsorted Array:");
        printArray(array);
        array=sorter.sortArray(array);
        System.out.println("\n Sorted Array: ");
        printArray(array);


    }
    public static void printArray(int[] array){
        for (int number : array){
            System.out.printf("%d, ",number);
        }
    }
}
