import java.util.Scanner;
public class Sorting {
    public Scanner keyboard=new Scanner(System.in);
    public int[] getArray(){
        int[] array=new int[5];
        for(int i=0;i<5;i++){
            System.out.println("Give me a integer");
            int userInput=Integer.parseInt(keyboard.nextLine());
            array[i]=userInput;
        }
        return array;
    }
    public int[] sortArray(int[] userArray){
        int temp;
        for(int i=1;i<userArray.length;i++){
            for (int j=i;j>0;j--){
                if (userArray[j]<userArray[j-1]){
                    temp=userArray[j];
                    userArray[j]=userArray[j-1];
                    userArray[j-1]=temp;
                }
            }
        }
        return userArray;

    }
}
