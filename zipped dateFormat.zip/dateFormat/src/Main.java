import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        TotalCalories total= new TotalCalories();
        Scanner keyboard= new Scanner(System.in);

        System.out.println("How many calories are you taking per day?");
        int calories=Integer.parseInt(keyboard.nextLine());
        System.out.println("What is your start date, please enter in mm/dd/yyyy format");
        String startDate=keyboard.nextLine();
        System.out.println("What is your end date for the diet, please enter in mm/dd/yyyy format:");
        String endDate=keyboard.nextLine();

        int totalCals= total.calcCalories(calories,startDate,endDate);
        System.out.printf("You consumed %d calories over the course of the diet.",totalCals);
    }
}
