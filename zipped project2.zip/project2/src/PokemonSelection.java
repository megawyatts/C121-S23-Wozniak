import java.util.Scanner;
public class PokemonSelection {
    public Scanner keyboard=new Scanner(System.in);
    public String name;
    public String move;
    public int movePower, attackSpeed;
    public int hitPoints;
    public String targetValue;
    public void Pokemon(){
    }
    public Object createPokemon(){
        String input;
        String optionsText="";
        Pokemon pokemon=new Pokemon();
        String name="null";
        String move="null";
        int movePower=0;
        int attackSpeed=0;
        int hitPoints=0;
        while(true){
            optionsText=testOptions(name,move,movePower,attackSpeed,hitPoints,optionsText);
            if (optionsText.equals("End")){
                return pokemon;
            }
            System.out.printf("What value would you like to address to make your pokemon?\n%s",optionsText);
            input=keyboard.nextLine();
            targetValue=testInput(input);
            if(targetValue.equals("NA")){
                System.out.println("You did not enter a correct keybind for a value, please try again.");
            }else{
                if(targetValue.equals("Name")){
                    name=getStringInput(targetValue);
                }else if(targetValue.equals("Move")){
                    move=getStringInput(targetValue);
                }else if(targetValue.equals("Move Power")){
                    movePower=getIntInput(targetValue);
                }else if(targetValue.equals("Attack Speed")){
                    attackSpeed=getIntInput(targetValue);
                }else{
                    hitPoints=getIntInput(targetValue);
                }
            }
        }


    }


    private String testOptions(String name,String move,int movePower,int attackSpeed,int hitPoints,String optionsText){
        // testing if there is any input in the values, so as to customize what the user should enter to complete their pokemon.
        optionsText="";
        if(name.equals("null")){
            optionsText=optionsText+"[N]Name\n";
        }
        if(move.equals("null")){
            optionsText=optionsText+"[M]Move\n";
        }
        if(movePower==0){
            optionsText=optionsText+"[MP]Move Power\n";
        }
        if(attackSpeed==0){
            optionsText=optionsText+"[A]Attack Speed\n";
        }
        if(hitPoints==0){
            optionsText=optionsText+"[H]Hit Points\n";
        }
        if(optionsText.equals("")){
            return "End";
        }
        return optionsText;
    }
    private String testInput(String input){
        //System.out.println("What is going to be your value for %s?");
        if(input.equals("N")||input.equals("n")){
            return "Name";
        }else if(input.equals("M")||input.equals("m")){
            return "Move";
        }else if(input.equals("MP")||input.equals("Mp")||input.equals("mP")||input.equals("mp")){
            return "Move Power";
        }else if(input.equals("A")||input.equals("a")){
            return "Attack Speed";
        }else if(input.equals("H")||input.equals("h")){
            return "Hit Points";
        }else{
            return "NA";
        }
    }
    private String getStringInput(String target){
        //Just a way to better shorten the main method and not have too many if statements in the main
        System.out.printf("\nWhat is the %s of your pokemon?",target);
        return keyboard.nextLine();
    }
    private int getIntInput(String target){
        //a way to shorten main mthod like getStringInput
        System.out.printf("What is the value of %s for your pokemon?",target);
        return Integer.parseInt(keyboard.nextLine());
    }
    public void assignPokemon(){
        // I cannot figure out how to use constructors,
        //Non-working
        System.out.println("Player 1: Select your Pokemon and then select which stat you want to edit.");
        Pokemon pokemonOne=new Pokemon();
        System.out.println("Player 2: Select your Pokemon and then select which stat you want to edit.");
        PokemonSelection pokemonTwo=new PokemonSelection();
        pokemonTwo.createPokemon();
        System.out.println("Player One Stats");
        Pokemon pokemon=new Pokemon();
        System.out.print(pokemon.displayPokemonStats(pokemonOne));
    }
}
