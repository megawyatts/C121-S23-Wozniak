public class Main {
    public static void main(String[] args) {
        PokemonSelection pokemon=new PokemonSelection();
        pokemon.assignPokemon();
    }
}
