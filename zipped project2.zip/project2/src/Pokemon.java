public class Pokemon {
    public String name;
    private String move;
    private int movePower, attackSpeed;
    public int hitPoints;

    public void Pokemon(String name,int hitPoints,String move, int movePower,int attackSpeed){
        this.name=getName();
        this.move=getMove();
        this.movePower=getMovePower();
        this.attackSpeed=getAttackSpeed();
        this.hitPoints=getHitPoints();
    }
    private String getMove(){
        return move;
    }
    private void setMove(String move){
        this.move=move;
    }
    private void setName(String name){
        this.name=name;
    }
    private String getName(){
        return name;
    }
    private void setMovePower(int movePower){
        this.movePower=movePower;
    }
    private int getMovePower(){
        return movePower;
    }
    private void setAttackSpeed(int attackSpeed){
        this.attackSpeed=attackSpeed;
    }
    private int getAttackSpeed(){
        return attackSpeed;
    }
    private void setHitPoints(int hitPoints){
        this.hitPoints=hitPoints;
    }
    private int getHitPoints(){
        return hitPoints;
    }
    public String displayPokemonStats(Object pokemon){
        return(String.format("Name: %s\nHit Points: %d\nMove: %s\n" +
                "Move Power: %d\n Attack Speed: %d",getName(),getHitPoints(),getMove(),getMovePower(),getAttackSpeed()));
    }
}
