package SetsAndIterators;

public class Main {
    public static void main(String[] args){
        StudentSet students=new StudentSet();
        students.addStudents();
        students.displayStudents();
    }
}
