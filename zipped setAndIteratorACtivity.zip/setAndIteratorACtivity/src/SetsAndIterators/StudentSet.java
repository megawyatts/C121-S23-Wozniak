package SetsAndIterators;
import java.util.HashSet;
import java.util.Set;
import java.util.Scanner;
import java.util.Iterator;
public class StudentSet {
    public Set<String> students= new HashSet<>();
    public Scanner keyboard=new Scanner(System.in);

    public void addStudents(){
        String input;
        while(true){
            System.out.println("Enter the name of a student or enter \"q\" to quit");
            input=keyboard.nextLine();
            if (input.equals("q")||input.equals("Q")){
                break;
            }
            students.add(input);
        }
    }

    public void displayStudents(){
        Iterator<String> iter= students.iterator();
        while(iter.hasNext()){
            System.out.println(iter.next());
        }
    }

}
