import com.sun.source.tree.ArrayAccessTree;

import java.lang.annotation.ElementType;
import java.util.ArrayList;
public class Main {


    public static void main(String[] args) {
        GenericMethods generic = new GenericMethods();
        ArrayList<Integer>intArrayList = new ArrayList<Integer>();
        ArrayList <Double> douArrayList= new ArrayList<Double>();
        ArrayList<Character> charArrayList= new ArrayList<Character>();
        ArrayList<String> stringArrayList= new ArrayList<>();

        for(int i=1;i<6;i++){
            intArrayList.add(i);
        }
        for (int j=1;j<6;j++){
            douArrayList.add((double)j+0.4);
        }
        charArrayList.add('A');
        charArrayList.add('B');
        charArrayList.add('C');
        charArrayList.add('D');

        stringArrayList.add("Juno");
        stringArrayList.add("Peter");
        stringArrayList.add("Buddy");
        stringArrayList.add("Vespa");

        System.out.print("Integer List: ");
        generic.printArrayList(intArrayList);
        System.out.print("Double Array List: ");
        generic.printArrayList(douArrayList);
        System.out.print("Character Array List: ");
        generic.printArrayList(charArrayList);
        System.out.print("String Array List: ");
        generic.printArrayList(stringArrayList);
    }
}
