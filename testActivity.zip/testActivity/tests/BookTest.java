import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BookTest {
    Book test= new Book("Juno Steel","Kevin Vibert",32,2015);
    @Test
    void getTitle() {
        assertEquals("Second Citadel",test.getTitle());
        //Passes Right
        //assertEquals("Juno Steel", test.getTitle());
    }

    @Test
    void getAuthor() {
        assertEquals("Harley Tagaki Kaner",test.getAuthor());
        //Passes right
        //assertEquals("Kevin Vibert", test.getAuthor());
    }
}