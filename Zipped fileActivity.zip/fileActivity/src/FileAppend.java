import javax.swing.JOptionPane;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
public class FileAppend {
    public static void main(String[] args)throws IOException{
        try{
            FileWriter fileWriter=new FileWriter("yourClasses.txt",true);
            PrintWriter output=new PrintWriter(fileWriter);
            String yourClass=JOptionPane.showInputDialog("Enter your class name.");
            String grade=JOptionPane.showInputDialog(String.format("Enter your grade in %s",yourClass));
            String averageScore=JOptionPane.showInputDialog(String.format("Enter your average score in %s",yourClass));

            output.printf("%s %s %s",yourClass,grade,averageScore);
            fileWriter.close();
            output.close();
        } catch(FileNotFoundException e){
            System.err.println("File not found.");
        }

    }
}
