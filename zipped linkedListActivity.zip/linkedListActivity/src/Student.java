import java.util.LinkedList;
public class Student {
    public String firstName,lastName,major,classStand;
    public int idNumb;
    public double gpa;
    public LinkedList<String> courses= new LinkedList<>();

    public Student(String firstName,String lastName,String major,String classStand,int idNumb,double gpa){
        this.firstName=firstName;
        this.lastName=lastName;
        this.major=major;
        this.classStand=classStand;
        this.idNumb=idNumb;
        this.gpa=gpa;
    }
    public void addCourse(String course){
        courses.add(course);
    }
    public void removeCourse(int position){
        courses.remove(position-1);
    }
    public String getStudentInfo(){
        String text=String.format("Name: %s %s\tID: %d\tMajor: %s\nClass Standing: %s\tGPA: %f\n",firstName,lastName,idNumb,major
        ,classStand,gpa);
        return text;
    }
    public void displayStudentCourses(){
        System.out.printf("Courses: %s\n",courses);
    }
}
