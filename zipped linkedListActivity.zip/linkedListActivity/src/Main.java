import java.util.LinkedList;
public class Main {
    public static void main(String[] args) {
        Student studentOne= new Student("Juno","Steel","Criminal Justice","Sophomore",544634,3.4);
        studentOne.addCourse("Criminal Method");
        studentOne.addCourse("Solve Crime 202");
        studentOne.addCourse("Fine Arts Class");
        studentOne.addCourse("Heist Time");
        System.out.print(studentOne.getStudentInfo());
        studentOne.displayStudentCourses();
        // remove course from Juno
        studentOne.removeCourse(3);
        studentOne.displayStudentCourses();

        // Vespa Time
        Student studentTwo=new Student("Vespa","Illkay","Medical","Senior",333224,3.8);
        studentTwo.addCourse("Criminal Method");
        studentTwo.addCourse("Anatomy and Physiology");
        studentTwo.addCourse("Heist Time");
        System.out.print(studentTwo.getStudentInfo());
        studentTwo.displayStudentCourses();
        //remove course and print again
        studentTwo.removeCourse(2);
        studentTwo.displayStudentCourses();
    }
}
