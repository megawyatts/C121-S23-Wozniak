import java.util.Scanner;
public class MethodsActivity {
    public static void main(String[] args){
        double recLength= getLength();
        double recWidth=getWidth();
        double recArea=getArea(recLength,recWidth);
        displayData(recLength,recWidth,recArea);
        scanner.close();
    }
    static Scanner scanner=new Scanner(System.in);
    public static Double getLength(){
        System.out.print("What is the length of the rectangle?");
        double length= Double.parseDouble(scanner.nextLine());
        return length;
    }
    public static Double getWidth(){
        System.out.print("What is the width of the rectangle?");
        double width=Double.parseDouble(scanner.nextLine());
        return width;
    }
    public static Double getArea(double l,double w){
        double areaTotal= l * w;
        return areaTotal;
    }
    public static void displayData(double l,double w,double areaRec){
        System.out.printf("Rectangle Length: %.1f\n",l);
        System.out.printf("Rectangle Width: %.1f\n",w);
        System.out.printf("Rectangle Area: %.1f\n",areaRec);
    }
}
