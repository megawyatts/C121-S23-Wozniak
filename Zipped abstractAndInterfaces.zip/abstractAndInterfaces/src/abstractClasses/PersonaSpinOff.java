package abstractClasses;

public class PersonaSpinOff extends PersonaEngine{
    private String gameEngine, spinoffType,gameTitle;
    private int yearPub;
    public PersonaSpinOff(String gameEngine,String spinoffType,String gameTitle,int yearPub){
        super(gameTitle,yearPub);
        this.gameEngine=gameEngine;
        this.spinoffType=spinoffType;
    }

    public void setSpinoffType(String type){
        spinoffType=type;
    }
    private String getSpinoffType(){
        return spinoffType;
    }
    public void setGameEngine(String engine){
        gameEngine=engine;
    }
    @Override
    public String getGameEngine(){
        return gameEngine;
    }

    @Override
    public String toString(){
        return super.toString()+String.format("Type of Spinoff: %s \t Playable on: ",getSpinoffType(),getGameEngine());
    }
}
