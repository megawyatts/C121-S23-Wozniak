package abstractClasses;

public class PersonaJRPG extends PersonaEngine{
    private String gameEngine;
    private int gameHours;
    public PersonaJRPG(String gameEngine,int hours, String gameTitle,int yearPub){
        super(gameTitle,yearPub);
        this.gameEngine=gameEngine;
    }
    public void setGameHours(int gameHours){
        this.gameHours=gameHours;
    }
    private int getGameHours(){
        return gameHours;
    }
    public void setGameEngine(String engine){
        gameEngine=engine;
    }

    @Override
    public String getGameEngine(){
        return gameEngine;
    }
    @Override
    public String toString(){
        return super.toString()+String.format("Hours played: %d \t Playable on: %s",getGameHours(),getGameEngine());
    }
}
