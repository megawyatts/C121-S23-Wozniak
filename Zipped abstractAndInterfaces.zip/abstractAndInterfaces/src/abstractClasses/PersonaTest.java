package abstractClasses;

public class PersonaTest {
    public static void main(String[] args){
        PersonaJRPG persona4=new PersonaJRPG("Steam, Play Station, Switch",50,"Persona 4",2011);
        System.out.printf("This game is playable on %s\n",persona4.getGameEngine());

        PersonaSpinOff persona4Dance=new PersonaSpinOff("Play Station","Dance Rythmn game","Persona 4: Dancing All Night",2013);
        System.out.printf("This game is playable on%s\n",persona4Dance.getGameEngine());
    }
}
