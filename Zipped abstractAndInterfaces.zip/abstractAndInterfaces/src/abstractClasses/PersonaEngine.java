package abstractClasses;

public abstract class PersonaEngine {
    private String gameTitle;
    public String developer;
    private int yearPub;

    public PersonaEngine(String gameTitle,int yearPub){
        this.gameTitle=gameTitle;
        this.yearPub=yearPub;
        developer="ATLUS";
    }

    public String getGameTitle(){
        return gameTitle;
    }
    public abstract String getGameEngine();

    public String toString(){
        return String.format("%s by %s, published in %d",gameTitle,developer,yearPub);
    }
}
