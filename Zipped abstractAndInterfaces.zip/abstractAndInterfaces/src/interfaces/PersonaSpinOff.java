package interfaces;

public class PersonaSpinOff implements GameSystem{

    private String gameEngine, spinoffType;
    public PersonaSpinOff(String gameEngine,String spinoffType){
        this.gameEngine=gameEngine;
        this.spinoffType=spinoffType;
    }

    public void setSpinoffType(String type){
        spinoffType=type;
    }
    private String getSpinoffType(){
        return spinoffType;
    }
    public void setGameEngine(String engine){
        gameEngine=engine;
    }
    @Override
    public String getGameEngine(){
        return gameEngine;
    }

    @Override
    public String toString(){
        return String.format("Type of Spinoff: %s \t Playable on: ",getSpinoffType(),getGameEngine());
    }
}
