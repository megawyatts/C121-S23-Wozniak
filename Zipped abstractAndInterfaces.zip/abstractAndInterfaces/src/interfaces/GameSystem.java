package interfaces;

public interface GameSystem {
    String getGameEngine();
}
