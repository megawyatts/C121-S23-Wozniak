public class Test {
    public static void main(String[] args){
        BigO big_o= new BigO();
        big_o.printOnce("Hello World!");
        big_o.printNTimes(3);
        big_o.printNSquaredTimes(3);
        
    }
}
