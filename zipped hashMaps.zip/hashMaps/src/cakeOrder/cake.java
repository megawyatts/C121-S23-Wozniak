package cakeOrder;
import java.util.HashMap;
public class cake {
    public HashMap<String,String> CakeOrder= new HashMap<>();

    public void addCake(String name,String cakeInput){
        CakeOrder.put(name,cakeInput);
    }
    public void removeCake(String name){
        CakeOrder.remove(name);
    }
    public String getCake(String name){
        return CakeOrder.get(name);
    }
    public void displayCakeOrder(String name){
        System.out.printf("Cake Order: %s\t Type: %s\n",name,getCake(name));
    }
}
