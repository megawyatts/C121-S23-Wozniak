package cakeOrder;

public class Main {
    public static void main(String[] args) {
        cake cakeMake= new cake();
        cakeMake.addCake("McRonalds","Chocolate");
        cakeMake.addCake("Evans","Chocolate");
        cakeMake.addCake("Tenma","Strawberry Shortcake");

        cakeMake.displayCakeOrder("Evans");
        cakeMake.displayCakeOrder("McRonalds");
        cakeMake.displayCakeOrder("Tenma");

        //remove
        cakeMake.removeCake("McRonalds");

        cakeMake.displayCakeOrder("Tenma");
        cakeMake.displayCakeOrder("Evans");cakeMake.displayCakeOrder("McRonalds");

        //Find a way to loop through objects
        }
    }

