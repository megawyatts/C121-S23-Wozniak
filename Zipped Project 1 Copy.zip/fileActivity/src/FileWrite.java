import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
import javax.swing.JOptionPane;
public class FileWrite {
    public static void main(String[] args)throws IOException{
        try{
            FileWriter fileWriter= new FileWriter("yourClasses.txt");
            PrintWriter output=new PrintWriter(fileWriter);

            String yourClass;
            String grade;
            String averageScore;

            output.println("Class  Grade  Average");
            for (int i=1;i<4;i++){
                yourClass=JOptionPane.showInputDialog(String.format("Enter the name of Class %d",i));
                grade=JOptionPane.showInputDialog(String.format("Enter the grade you have for %s",yourClass));
                averageScore=JOptionPane.showInputDialog(String.format("Enter your average score you have in %s",yourClass));

                output.printf("%s %s %s\n",yourClass,grade,averageScore);
            }
            fileWriter.close();
            output.close();
        }
        catch(FileNotFoundException e){
            System.err.println("File not found, sorry.");
        }

    }
}
