import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;
public class FileRead {
    public static void main(String[] args) throws FileNotFoundException{
        File classes=new File("classes.txt");

        try{
            Scanner read = new Scanner(classes);

            while (read.hasNextLine()){
                String line=read.nextLine();
                System.out.println(line);
            }
            read.close();
        } catch(FileNotFoundException e){
            System.err.println("Classes not found.");
        }
    }

}
