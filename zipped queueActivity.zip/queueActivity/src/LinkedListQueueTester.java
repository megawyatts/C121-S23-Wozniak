
public class LinkedListQueueTester {
    public static void main(String[] args) {
        LinkedListQueue queue= new LinkedListQueue();
        // first one
        queue.enqueue("Tom");
        queue.enqueue("Jane");
        queue.enqueue("Beth");
        System.out.println("\n1. ");
        System.out.printf(queue.displayQueue());

        //second one
        queue.enqueue("John");
        queue.enqueue("Mary");
        System.out.println("\n2.");
        System.out.printf(queue.displayQueue());

        //third one
        System.out.println("\n3. ");
        System.out.printf(queue.getQueueData(true,true,true));
        queue.dequeue();

        // fourth one
        System.out.println("\n4.");
        System.out.printf(queue.displayQueue());

        //fifth one
        System.out.println("\n5.");
        System.out.printf(queue.getQueueData(true,true,true));

        //sixth one
        System.out.println("\n6.");
        queue.dequeue();
        System.out.printf(queue.getQueueData(false,false,true));

        //seventh one
        System.out.println("\n7.");
        queue.dequeue();//removing beth
        System.out.printf(queue.getQueueData(false,false,true));

        //eighth one
        System.out.println("\n8.");
        queue.dequeue();//removing John
        System.out.printf(queue.getQueueData(false,false,true));

        //ninth one
        System.out.println("\n9.");
        queue.dequeue();//removing Mary
        System.out.printf(queue.getQueueData(false,false,true));

        //tenth one
        System.out.println("\n10.");
        System.out.printf(queue.getQueueData(true,false,false));


    }
}
